# pack1/mymod1
tot = 100    # 전역 변수

def listHap(*ar):
    print(ar)
    if __name__ == '__main__':
        print('나는 메인모듈~~~')

def kbs():
    print('대한민국 대표방송')

def mbc():
    print('문화방송')