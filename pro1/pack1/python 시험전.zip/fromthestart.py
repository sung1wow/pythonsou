"""
문제 1) 다음 코드에서 변수 a, b, c의 데이터 타입을 작성하시오.
     a = 3.14     - float
     b = True     - bool
     c = “False”  - str
"""


"""
문제 2) 두 개의 숫자를 입력받아 다음 연산 결과를 출력하는 프로그램을 작성하시오.
	덧셈, 뺄셈, 곱셈, 나눗셈
"""
# num1 = float(input('첫 번째 숫자를 입력하세요 : '))
# num2 = float(input('두 번째 숫자를 입력하세요 : '))

# print(f'덧셈 결과 : {num1 + num2}')
# print(f'뺄셈 결과 : {num1 - num2}')
# print(f'곱셈 결과 : {num1 * num2}')
# print(f'나눗셈 결과 : {num1 / num2}')


"""
문제 2) 점수를 입력 받아 다음조건에 따라 학점을 출력하는 프로그램을 작성하시오.
- 90점 이상: A학점
- 80점 이상 90점 미만: B학점
- 70점 이상 80점 미만: C학점
- 70점 미만: F학점
"""
# score = float(input('점수를 입력하세요 : '))

# if score >= 90:
#     print('A')
# elif score >= 80 and score < 90:
#     print('B')
# elif score >= 70 and score < 80:
#     print('C')
# elif score < 70:
#     print('F')


"""
문제 3) 다음 리스트에서 “lemon”만 출력하는 프로그램을 작성하시오.
fruits = [“banana”, “peach”, “lemon”, “grape”]
"""
fruits = ['“banana”, “peach”, “lemon”, “grape”']
print([fruits, 2])


"""
문제 2) 다음 딕셔너리에 키 “도시” 추가하고 값 “취미”를 빼고 모든 키를 출력하는 프로그램을 작성하시오.
	student3 = {“나이”: 22, “직업”: “학생”, “취미”: “게임”}

문제 1) 다음 리스트에 저장된 모든 값을 출력하는 프로그램을 작성하시오.
	Numbers = [1, 2, 3, 4, 5]

문제 2) fruits 리스트에 저장된 과일 이름을 하나씩 출력하면서 “사과”가 포함된 경우 “사과를 찾았습니다!” 라는 메시지를 출력하는 프로그램을 작성하시오.
	fruits = [‘바나나’, ‘파인애플’, ‘복숭아’, ‘사과’, ‘포도’]
"""